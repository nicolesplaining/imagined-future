# Cosmos 3 archival selection-free result

90 states, 30 archived episodes, six tasks; all four future sources per state.

| Estimand | Equal-task mean | Hierarchical 95% CI |
|---|---:|---:|
| Future-source retrieval (chance 0.25) | 1.000 | [1.000, 1.000] |
| Off-diagonal donor retrieval | 1.000 | [1.000, 1.000] |
| Shuffled-label retrieval | 0.000 | [0.000, 0.000] |
| Gaussian-target donor retrieval | 0.000 | [0.000, 0.000] |
| Distance reduction toward donor | 0.763 | [0.733, 0.792] |
| Cosine alignment | 0.967 | [0.957, 0.975] |
| Normalized orthogonal residual | 0.227 | [0.200, 0.255] |
| Normalized donor-axis projection | 0.966 | [0.956, 0.974] |

Permutation p-value for four-source retrieval: 9.999e-05.

Scope: predicted actions from frozen archival observations; no physical-endpoint or task-success estimate.
