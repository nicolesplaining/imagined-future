# Cosmos 3 future-strength dose response

| Donor mixture $\alpha$ | Distance reduction | Donor-axis projection | Correct-donor retrieval |
|---:|---:|---:|---:|
| 0 | -0.022 [-0.040, -0.007] | -0.002 [-0.017, 0.011] | 0.000 [0.000, 0.000] |
| .25 | 0.033 [0.018, 0.046] | 0.056 [0.042, 0.073] | 0.003 [0.000, 0.011] |
| .50 | 0.232 [0.194, 0.264] | 0.303 [0.268, 0.334] | 0.142 [0.103, 0.183] |
| .75 | 0.712 [0.664, 0.753] | 0.877 [0.856, 0.895] | 0.992 [0.981, 1.000] |
| 1 | 0.763 [0.716, 0.800] | 0.969 [0.954, 0.983] | 1.000 [1.000, 1.000] |

Primary distance-reduction slope: 0.899 [0.852, 0.936].

Values are equal-task means with task-to-state hierarchical 95% bootstrap intervals over 30 fixed states from six tasks.
